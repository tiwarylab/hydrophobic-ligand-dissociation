Code for the paper "Machine-learned reaction coordinates for hydrophobic ligand dissociation"
